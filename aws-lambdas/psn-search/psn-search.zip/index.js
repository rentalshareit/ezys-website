const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const zlib = require("zlib");

const s3 = new S3Client({ region: "ap-south-1" });
const BUCKET = process.env.BUCKET_NAME;
const KEY = "psn-games-latest.json.gz";

exports.handler = async (event) => {
  // CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
      body: "",
    };
  }

  try {
    // 1. Fetch & decompress S3 data
    console.log("Fetching S3 data...");
    const { Body } = await s3.send(
      new GetObjectCommand({ Bucket: BUCKET, Key: KEY }),
    );
    const arrayBuffer = await Body.transformToByteArray();
    const decompressed = zlib.gunzipSync(arrayBuffer);
    const gamesData = JSON.parse(decompressed.toString());

    console.log(`Loaded ${gamesData.count} games`);

    // 2. Parse request
    const body = JSON.parse(event.body || "{}");
    const { query = "" } = body;
    const queries = query
      .split(",")
      .map((q) => q.trim())
      .filter(Boolean);

    console.log(`Searching for: ${queries.join(", ")}`);

    // 3. Smart token-based search (handles GTA5 → Grand Theft Auto V)
    const results = await Promise.all(
      queries.map(async (q) => {
        const matches = smartTokenSearch(gamesData.games, q);
        return {
          query: q,
          found: matches.length > 0,
          games: matches.slice(0, 3), // Top 3 matches
          totalMatches: matches.length,
        };
      }),
    );

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
      body: JSON.stringify({
        results,
        totalGames: gamesData.count,
        updatedAt: gamesData.updatedAt,
        queryCount: queries.length,
      }),
    };
  } catch (error) {
    console.error("Search failed:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        error: error.message,
        success: false,
      }),
    };
  }
};

// 🧠 Smart token matching - "gta5" → "Grand Theft Auto V"
function smartTokenSearch(games, query) {
  const queryTokens = query
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter(Boolean);

  if (queryTokens.length === 0) return [];

  const scoredGames = games
    .map((game) => {
      const gameTokens = game.nameOriginal.toLowerCase().split(/\s+/);
      let score = 0;
      const matches = [];

      queryTokens.forEach((token) => {
        // Exact word match (weight: 3)
        if (gameTokens.includes(token)) {
          score += 3;
          matches.push(token);
        }
        // Partial match - token in game word (weight: 2)
        else if (gameTokens.some((gt) => gt.includes(token))) {
          score += 2;
          matches.push(token);
        }
        // Partial match - game word in token (weight: 1)
        else if (
          token.length > 2 &&
          gameTokens.some((gt) => token.includes(gt))
        ) {
          score += 1;
          matches.push(token);
        }
      });

      // Bonus: Exact title match
      if (game.nameOriginal.toLowerCase().includes(query.toLowerCase())) {
        score += 10;
      }

      // Bonus: More tokens matched = better
      const coverage = matches.length / queryTokens.length;
      score += coverage * 2;

      return {
        game,
        score: score * 100, // Scale for readability
        matches,
        coverage,
      };
    })
    .filter((item) => item.score > 50) // Minimum relevance
    .sort((a, b) => b.score - a.score);

  return scoredGames.map((item) => item.game);
}
