// ============================================
// COMPLETE OPENCART API WRAPPER LAMBDA
// Production Ready with Public & Authenticated Routes
// ============================================

const mysql = require("mysql2/promise");
const jwt = require("jsonwebtoken");
const axios = require("axios");

// Configuration
const CONFIG = {
  db: {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT || 3306,
  },
  opencart: {
    url: process.env.OPENCART_URL,
    apiUsername: process.env.OPENCART_API_USERNAME,
    apiKey: process.env.OPENCART_API_KEY,
  },
  jwt: {
    secret: process.env.JWT_SECRET,
  },
};

async function getDBConnection() {
  return await mysql.createConnection(CONFIG.db);
}

// ============================================
// SESSION MANAGEMENT
// ============================================

// Get or create authenticated OpenCart session for customer
async function getAuthenticatedSession(connection, customerId) {
  // Check for recent session (< 20 minutes old)
  const [sessions] = await connection.execute(
    `SELECT * FROM opencart_sessions 
     WHERE customer_id = ? 
     AND last_activity > DATE_SUB(NOW(), INTERVAL 20 MINUTE)
     ORDER BY created_at DESC 
     LIMIT 1`,
    [customerId],
  );

  if (sessions.length > 0) {
    await connection.execute(
      "UPDATE opencart_sessions SET last_activity = NOW() WHERE id = ?",
      [sessions[0].id],
    );

    console.log(`Reusing authenticated session for customer ${customerId}`);
    return {
      api_token: sessions[0].opencart_api_token,
      session_id: sessions[0].opencart_session_id,
    };
  }

  // Create new authenticated session
  console.log(`Creating new authenticated session for customer ${customerId}`);
  const session = await createAuthenticatedSession(customerId);

  await connection.execute(
    `INSERT INTO opencart_sessions 
     (customer_id, opencart_api_token, opencart_session_id, created_at, last_activity) 
     VALUES (?, ?, ?, NOW(), NOW())`,
    [customerId, session.api_token, session.session_id],
  );

  return session;
}

// Create authenticated OpenCart session with customer_id set
async function createAuthenticatedSession(customerId) {
  try {
    // Step 1: Login to OpenCart API
    const loginResponse = await axios.post(
      `${CONFIG.opencart.url}/index.php?route=api/account/login`,
      new URLSearchParams({
        username: CONFIG.opencart.apiUsername,
        key: CONFIG.opencart.apiKey,
      }),
    );

    const apiToken = loginResponse.data.api_token;
    const sessionCookie = loginResponse.headers["set-cookie"]?.[0];
    const sessionId = sessionCookie?.match(/PHPSESSID=([^;]+)/)?.[1];

    // Step 2: Set customer in session
    await axios.post(
      `${CONFIG.opencart.url}/index.php?route=api/sale/customer&api_token=${apiToken}`,
      new URLSearchParams({ customer_id: customerId.toString() }),
      {
        headers: {
          Cookie: sessionCookie || `PHPSESSID=${sessionId}`,
        },
      },
    );

    console.log(`Authenticated session created for customer ${customerId}`);
    return { api_token: apiToken, session_id: sessionId };
  } catch (error) {
    console.error(
      "Failed to create authenticated session:",
      error.response?.data || error.message,
    );
    throw new Error("Failed to create OpenCart session");
  }
}

// Get public OpenCart API session (no customer)
async function getPublicSession(connection) {
  // Check for recent public session (< 20 minutes old)
  const [sessions] = await connection.execute(
    `SELECT * FROM opencart_public_sessions 
     WHERE last_activity > DATE_SUB(NOW(), INTERVAL 20 MINUTE)
     ORDER BY created_at DESC 
     LIMIT 1`,
  );

  if (sessions.length > 0) {
    await connection.execute(
      "UPDATE opencart_public_sessions SET last_activity = NOW() WHERE id = ?",
      [sessions[0].id],
    );

    console.log("Reusing public session");
    return {
      api_token: sessions[0].opencart_api_token,
      session_id: sessions[0].opencart_session_id,
    };
  }

  // Create new public session
  console.log("Creating new public session");
  const session = await createPublicSession();

  await connection.execute(
    `INSERT INTO opencart_public_sessions 
     (opencart_api_token, opencart_session_id, created_at, last_activity) 
     VALUES (?, ?, NOW(), NOW())`,
    [session.api_token, session.session_id],
  );

  return session;
}

// Create public OpenCart session (no customer)
async function createPublicSession() {
  try {
    const loginResponse = await axios.post(
      `${CONFIG.opencart.url}/index.php?route=api/account/login`,
      new URLSearchParams({
        username: CONFIG.opencart.apiUsername,
        key: CONFIG.opencart.apiKey,
      }),
    );

    const apiToken = loginResponse.data.api_token;
    const sessionCookie = loginResponse.headers["set-cookie"]?.[0];
    const sessionId = sessionCookie?.match(/PHPSESSID=([^;]+)/)?.[1];

    console.log("Public session created");
    return { api_token: apiToken, session_id: sessionId };
  } catch (error) {
    console.error(
      "Failed to create public session:",
      error.response?.data || error.message,
    );
    throw new Error("Failed to create public session");
  }
}

// ============================================
// OPENCART API CALLER
// ============================================

async function callOpenCartAPI(connection, route, options = {}) {
  const {
    method = "GET",
    data = {},
    queryParams = {},
    customerId = null,
    requiresAuth = false,
  } = options;

  // Get appropriate session
  let session;
  if (requiresAuth && customerId) {
    session = await getAuthenticatedSession(connection, customerId);
  } else {
    session = await getPublicSession(connection);
  }

  // Build URL with query parameters
  const params = new URLSearchParams({
    ...queryParams,
    api_token: session.api_token,
  });
  const url = `${CONFIG.opencart.url}/index.php?route=${route}&${params.toString()}`;

  try {
    const response = await axios({
      method,
      url,
      data: method !== "GET" ? new URLSearchParams(data) : undefined,
      headers: {
        Cookie: `PHPSESSID=${session.session_id}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
    });

    return response.data;
  } catch (error) {
    // Handle session expiry
    if (
      error.response?.status === 401 ||
      error.response?.data?.error?.includes("permission")
    ) {
      console.log("Session expired, re-authenticating...");

      // Delete expired session
      if (requiresAuth && customerId) {
        await connection.execute(
          "DELETE FROM opencart_sessions WHERE customer_id = ?",
          [customerId],
        );
        session = await createAuthenticatedSession(customerId);
        await connection.execute(
          `INSERT INTO opencart_sessions 
           (customer_id, opencart_api_token, opencart_session_id, created_at, last_activity) 
           VALUES (?, ?, ?, NOW(), NOW())`,
          [customerId, session.api_token, session.session_id],
        );
      } else {
        await connection.execute(
          "DELETE FROM opencart_public_sessions WHERE id = ?",
          [session.id],
        );
        session = await createPublicSession();
        await connection.execute(
          `INSERT INTO opencart_public_sessions 
           (opencart_api_token, opencart_session_id, created_at, last_activity) 
           VALUES (?, ?, NOW(), NOW())`,
          [session.api_token, session.session_id],
        );
      }

      // Retry with new session
      const retryParams = new URLSearchParams({
        ...queryParams,
        api_token: session.api_token,
      });
      const retryUrl = `${CONFIG.opencart.url}/index.php?route=${route}&${retryParams.toString()}`;

      const retryResponse = await axios({
        method,
        url: retryUrl,
        data: method !== "GET" ? new URLSearchParams(data) : undefined,
        headers: {
          Cookie: `PHPSESSID=${session.session_id}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
      });

      return retryResponse.data;
    }

    throw error;
  }
}

// ============================================
// PUBLIC API ENDPOINTS (No Auth Required)
// ============================================

async function getProducts(queryParams) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(connection, "api/catalog/product", {
      method: "GET",
      queryParams,
      requiresAuth: false,
    });
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function getProduct(productId) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(connection, "api/catalog/product", {
      method: "GET",
      queryParams: { product_id: productId },
      requiresAuth: false,
    });
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function searchProducts(queryParams) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(
      connection,
      "api/catalog/product|search",
      {
        method: "GET",
        queryParams,
        requiresAuth: false,
      },
    );
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function getCategories(queryParams) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(connection, "api/catalog/category", {
      method: "GET",
      queryParams,
      requiresAuth: false,
    });
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function getCategory(categoryId) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(connection, "api/catalog/category", {
      method: "GET",
      queryParams: { category_id: categoryId },
      requiresAuth: false,
    });
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function getCategoryProducts(categoryId, queryParams) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(
      connection,
      "api/catalog/category|products",
      {
        method: "GET",
        queryParams: { category_id: categoryId, ...queryParams },
        requiresAuth: false,
      },
    );
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

// ============================================
// AUTHENTICATED API ENDPOINTS (Require Auth)
// ============================================

async function addToCart(customerId, data) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(connection, "api/sale/cart", {
      method: "POST",
      data,
      customerId,
      requiresAuth: true,
    });
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function getCart(customerId) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(connection, "api/sale/cart", {
      method: "GET",
      customerId,
      requiresAuth: true,
    });
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function removeFromCart(customerId, key) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(connection, "api/sale/cart", {
      method: "POST",
      data: { key, quantity: 0 },
      customerId,
      requiresAuth: true,
    });
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function setShippingAddress(customerId, address) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(
      connection,
      "api/sale/shipping_address",
      {
        method: "POST",
        data: address,
        customerId,
        requiresAuth: true,
      },
    );
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function setPaymentAddress(customerId, address) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(
      connection,
      "api/sale/payment_address",
      {
        method: "POST",
        data: address,
        customerId,
        requiresAuth: true,
      },
    );
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function getShippingMethods(customerId) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(
      connection,
      "api/sale/shipping_method",
      {
        method: "GET",
        customerId,
        requiresAuth: true,
      },
    );
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function setShippingMethod(customerId, method) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(
      connection,
      "api/sale/shipping_method",
      {
        method: "POST",
        data: { shipping_method: method },
        customerId,
        requiresAuth: true,
      },
    );
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function getPaymentMethods(customerId) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(
      connection,
      "api/sale/payment_method",
      {
        method: "GET",
        customerId,
        requiresAuth: true,
      },
    );
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function setPaymentMethod(customerId, method) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(
      connection,
      "api/sale/payment_method",
      {
        method: "POST",
        data: { payment_method: method },
        customerId,
        requiresAuth: true,
      },
    );
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function createOrder(customerId) {
  const connection = await getDBConnection();
  try {
    const result = await callOpenCartAPI(connection, "api/sale/order", {
      method: "POST",
      customerId,
      requiresAuth: true,
    });
    return { statusCode: 200, body: JSON.stringify(result) };
  } finally {
    await connection.end();
  }
}

async function getCustomerOrders(customerId) {
  const connection = await getDBConnection();
  try {
    const [orders] = await connection.execute(
      "SELECT * FROM oc_order WHERE customer_id = ? ORDER BY date_added DESC",
      [customerId],
    );
    return { statusCode: 200, body: JSON.stringify({ orders }) };
  } finally {
    await connection.end();
  }
}

async function getOrder(customerId, orderId) {
  const connection = await getDBConnection();
  try {
    const [orders] = await connection.execute(
      "SELECT * FROM oc_order WHERE order_id = ? AND customer_id = ?",
      [orderId, customerId],
    );

    if (orders.length === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: "Order not found" }),
      };
    }

    const [products] = await connection.execute(
      "SELECT * FROM oc_order_product WHERE order_id = ?",
      [orderId],
    );

    return {
      statusCode: 200,
      body: JSON.stringify({
        order: orders[0],
        products,
      }),
    };
  } finally {
    await connection.end();
  }
}

// ============================================
// SESSION MANAGEMENT
// ============================================

async function logout(customerId) {
  const connection = await getDBConnection();
  try {
    // Delete customer's sessions
    await connection.execute(
      "DELETE FROM opencart_sessions WHERE customer_id = ?",
      [customerId],
    );

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        message: "Logged out successfully",
      }),
    };
  } finally {
    await connection.end();
  }
}

async function checkSession(customerId) {
  const connection = await getDBConnection();
  try {
    const [sessions] = await connection.execute(
      `SELECT last_activity FROM opencart_sessions 
       WHERE customer_id = ? 
       AND last_activity > DATE_SUB(NOW(), INTERVAL 20 MINUTE)
       LIMIT 1`,
      [customerId],
    );

    if (sessions.length === 0) {
      return {
        statusCode: 200,
        body: JSON.stringify({
          active: false,
          message: "No active session",
        }),
      };
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        active: true,
        last_activity: sessions[0].last_activity,
      }),
    };
  } finally {
    await connection.end();
  }
}

// ============================================
// JWT VERIFICATION MIDDLEWARE
// ============================================

function verifyJWT(token) {
  try {
    const decoded = jwt.verify(token, CONFIG.jwt.secret);
    return { valid: true, customer_id: decoded.customer_id };
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return { valid: false, error: "Token expired", expired: true };
    }
    return { valid: false, error: "Invalid token" };
  }
}

// ============================================
// LAMBDA HANDLER
// ============================================

exports.handler = async (event) => {
  const path = event.path || event.rawPath || event.requestContext?.http?.path;
  const method = event.httpMethod || event.requestContext?.http?.method;
  const body = event.body ? JSON.parse(event.body) : {};
  const queryParams = event.queryStringParameters || {};
  const headers = event.headers || {};

  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  };

  if (method === "OPTIONS") {
    return { statusCode: 200, headers: corsHeaders, body: "" };
  }

  // ============================================
  // PUBLIC ROUTES (No Auth Required)
  // ============================================

  try {
    let response;

    // Products - Public
    if (path === "/products" && method === "GET") {
      response = await getProducts(queryParams);
    } else if (path.match(/^\/products\/\d+$/) && method === "GET") {
      const productId = path.split("/")[2];
      response = await getProduct(productId);
    } else if (path === "/products/search" && method === "GET") {
      response = await searchProducts(queryParams);
    }

    // Categories - Public
    else if (path === "/categories" && method === "GET") {
      response = await getCategories(queryParams);
    } else if (path.match(/^\/categories\/\d+$/) && method === "GET") {
      const categoryId = path.split("/")[2];
      response = await getCategory(categoryId);
    } else if (
      path.match(/^\/categories\/\d+\/products$/) &&
      method === "GET"
    ) {
      const categoryId = path.split("/")[2];
      response = await getCategoryProducts(categoryId, queryParams);
    }

    // ============================================
    // AUTHENTICATED ROUTES (Require JWT)
    // ============================================
    else {
      // Extract and verify JWT
      const token =
        headers.authorization?.replace("Bearer ", "") ||
        headers.Authorization?.replace("Bearer ", "");

      if (!token) {
        return {
          statusCode: 401,
          headers: corsHeaders,
          body: JSON.stringify({ error: "Authorization token required" }),
        };
      }

      const jwtCheck = verifyJWT(token);

      if (!jwtCheck.valid) {
        return {
          statusCode: 401,
          headers: corsHeaders,
          body: JSON.stringify({
            error: jwtCheck.error,
            expired: jwtCheck.expired || false,
          }),
        };
      }

      const customerId = jwtCheck.customer_id;

      // Cart
      if (path === "/cart/add" && method === "POST") {
        response = await addToCart(customerId, body);
      } else if (path === "/cart" && method === "GET") {
        response = await getCart(customerId);
      } else if (path === "/cart/remove" && method === "POST") {
        response = await removeFromCart(customerId, body.key);
      }

      // Checkout
      else if (path === "/checkout/shipping-address" && method === "POST") {
        response = await setShippingAddress(customerId, body);
      } else if (path === "/checkout/payment-address" && method === "POST") {
        response = await setPaymentAddress(customerId, body);
      } else if (path === "/checkout/shipping-methods" && method === "GET") {
        response = await getShippingMethods(customerId);
      } else if (path === "/checkout/shipping-method" && method === "POST") {
        response = await setShippingMethod(customerId, body.method);
      } else if (path === "/checkout/payment-methods" && method === "GET") {
        response = await getPaymentMethods(customerId);
      } else if (path === "/checkout/payment-method" && method === "POST") {
        response = await setPaymentMethod(customerId, body.method);
      }

      // Orders
      else if (path === "/order/create" && method === "POST") {
        response = await createOrder(customerId);
      } else if (path === "/orders" && method === "GET") {
        response = await getCustomerOrders(customerId);
      } else if (path.match(/^\/orders\/\d+$/) && method === "GET") {
        const orderId = path.split("/")[2];
        response = await getOrder(customerId, orderId);
      }

      // Session Management
      else if (path === "/session/status" && method === "GET") {
        response = await checkSession(customerId);
      } else if (path === "/logout" && method === "POST") {
        response = await logout(customerId);
      } else {
        response = {
          statusCode: 404,
          body: JSON.stringify({ error: "Not found" }),
        };
      }
    }

    return {
      ...response,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
    };
  } catch (error) {
    console.error("Lambda error:", error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: "Internal server error",
        message: error.message,
      }),
    };
  }
};
