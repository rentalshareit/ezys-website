const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { default: Meta } = require("antd/es/card/Meta");
const zlib = require("zlib");

const s3 = new S3Client({ region: "ap-south-1" });
const BUCKET = process.env.BUCKET_NAME;
const KEY = "psn-games-latest.json.gz";

const ENDPOINTS = [
  "https://www.playstation.com/bin/imagic/gameslist?locale=en-in&categoryList=plus-games-list",
  "https://www.playstation.com/bin/imagic/gameslist?locale=en-in&categoryList=plus-classics-list",
  "https://www.playstation.com/bin/imagic/gameslist?locale=en-in&categoryList=plus-monthly-games-list",
];

exports.handler = async () => {
  try {
    const allGames = [];
    for (const url of ENDPOINTS) {
      const response = await fetch(url);
      const data = await response.json();
      data.forEach((catalog) =>
        catalog.games.forEach((game) => {
          allGames.push({
            conceptId: game.conceptId,
            name: game.name.toLowerCase(),
            nameOriginal: game.name,
            devices: game.device,
            productId: game.productId,
            storeUrl: game.conceptUrl,
            imageUrl: game.imageUrl,
          });
        }),
      );
    }

    const gamesData = {
      games: allGames,
      updatedAt: new Date().toISOString(),
      count: allGames.length,
    };
    const jsonString = JSON.stringify(gamesData);
    const compressed = zlib.gzipSync(jsonString);

    await s3.send(
      new PutObjectCommand({
        Bucket: BUCKET,
        Key: KEY,
        Body: compressed,
        ContentEncoding: "gzip",
        ContentType: "application/json",
        Metadata: { totalGames: allGames.length.toString() },
      }),
    );

    console.log(`✅ Saved ${allGames.length} games`);
    return { statusCode: 200, body: "Success" };
  } catch (error) {
    console.error("❌ Error:", error);
    return { statusCode: 500, body: error.message };
  }
};
